# Coding-Raja-Technologies-Internship-online-resume-builder
ONLINE RESUME BUILDING USING HTML , CSS AND JAVASCRIPT
LAYOUT OF THE ONLINE RESUME BUILDER
![Screenshot 2023-11-26 112509](https://github.com/Venkatasai25/Coding-Raja-Technologies-Internship-online-resume-builder-/assets/136894203/122baa6e-5c9b-43e0-8b34-4a4174c1c598)
![Screenshot 2023-11-26 112540](https://github.com/Venkatasai25/Coding-Raja-Technologies-Internship-online-resume-builder-/assets/136894203/f932de9e-b1f3-469d-87be-8c3b35b3c39f)
![Screenshot 2023-11-26 112611](https://github.com/Venkatasai25/Coding-Raja-Technologies-Internship-online-resume-builder-/assets/136894203/cd31dbe9-f06b-4ca7-af96-909007149770)
![Screenshot 2023-11-26 112630](https://github.com/Venkatasai25/Coding-Raja-Technologies-Internship-online-resume-builder-/assets/136894203/6140420a-4f32-4661-830d-8d0b32a7dcc9)
![Screenshot 2023-11-26 112652](https://github.com/Venkatasai25/Coding-Raja-Technologies-Internship-online-resume-builder-/assets/136894203/f13ac12b-f865-47b9-a38e-1f0cc4b87113)
![Screenshot 2023-11-26 112707](https://github.com/Venkatasai25/Coding-Raja-Technologies-Internship-online-resume-builder-/assets/136894203/eb1c5de0-3912-478c-baaa-881dfd451d38)
![Screenshot 2023-11-26 112726](https://github.com/Venkatasai25/Coding-Raja-Technologies-Internship-online-resume-builder-/assets/136894203/0effe8d4-4b7b-4719-90de-d52daa285702)







